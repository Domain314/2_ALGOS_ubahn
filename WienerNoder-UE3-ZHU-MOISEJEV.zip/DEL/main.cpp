#include <iostream>
#include "src/City.hpp"

int main() {
    City* city = new City();
    delete city;
    return 0;
}


/*
Reumannplatz - Simmering


 * */